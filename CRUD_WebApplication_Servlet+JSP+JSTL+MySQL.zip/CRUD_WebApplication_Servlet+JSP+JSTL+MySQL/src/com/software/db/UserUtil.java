package com.software.db;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class UserUtil {
private static Connection conn;
	
	public static Connection getConnection(){
		if(conn!=null)
			return conn;
		InputStream inputStream = UserUtil.class.getClassLoader().getResourceAsStream("/dataBase.properties");
		Properties properties = new Properties();
		try{
			properties.load(inputStream);
			String driver = properties.getProperty("driver");
			String url = properties.getProperty("url");
			String user = properties.getProperty("user");
			String password = properties.getProperty("password");
			Class.forName(driver);
			System.out.println("Connection was linked up successful");
			conn = DriverManager.getConnection(url, user, password);
		}
		catch(ClassNotFoundException e){
			System.out.println("ClassNotFoundException in Connecting to DB"+e.getMessage());}
		catch(IOException e){
			System.out.println("IOException in Connecting to DB"+e.getMessage());}
		catch(SQLException e){
			System.out.println("SQLException in Connecting to DB"+e.getMessage());}
		return conn;
	}
	public static void closeConnection (Connection connection){
		try{
			connection.close();
		}
		catch(SQLException e){System.out.println("SQLException in closeConnection() to DB"+e.getMessage());}
		}
	}

