package com.software.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.software.db.UserUtil;
import com.software.model.User;

public class UserDao {
	Connection conn;
	private int noOfRecords;

	public UserDao() {
		super();
		conn = UserUtil.getConnection();
	}
	
	public synchronized void addUser(User user){
		try {
			String sql = "insert into users (name,age,isadmin) values (?,?,?)";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, user.getName());
			ps.setString(2, user.getAge());
			ps.setBoolean(3, user.isIsadmin()); 
			
			ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Error in addUser() "+e.getMessage());
		}
	}
	public synchronized List<User> getAllUser(int offset, int noOfRecords){
		String sql = "select SQL_CALC_FOUND_ROWS * from users limit "+offset+", "+noOfRecords;
		List<User> users = new ArrayList<User>();
		User user = null;
		Statement st;
		try{
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()){
				user = new User();
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setAge(rs.getString("age"));
				user.setIsadmin(rs.getBoolean("isadmin"));
				user.setCreateddate(rs.getTimestamp("createddate"));
				users.add(user);
			}
			rs.close();
			rs = st.executeQuery("select FOUND_ROWS()");
			if(rs.next()){
				this.noOfRecords = rs.getInt(1);
			}
		}
		catch(SQLException e){
			System.out.println("Error in getAllUser() "+e.getMessage());
		}
		return users;
	}
	public synchronized void updateUser(User user){
		try{
			String sql = "update users set name=?, age=?, isadmin=?,createddate=? "
					+ "where id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, user.getName());
			ps.setString(2, user.getAge());
			ps.setBoolean(3, user.isIsadmin());
			ps.setTimestamp(4, new java.sql.Timestamp(System.currentTimeMillis()));
			ps.setInt(5, user.getId());
			ps.executeUpdate();
		}
		catch(SQLException e){
			System.out.println("Error in updateUser() "+e.getMessage());
		}
	}
	public synchronized void deleteUser(int userId){
		try{
			String sql = "delete from users where id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, userId);
			ps.executeUpdate();
		}
		catch(SQLException e){
			System.out.println("Error in deleteUser() "+e.getMessage());
		}
	}
	public synchronized User getUserById(int userId){
		User user = new User();
		try {
			String sql = "select * from users where id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, userId);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setAge(rs.getString("age"));
				user.setIsadmin(rs.getBoolean("isadmin"));
				user.setCreateddate(rs.getDate("createddate"));
			}
		} catch (SQLException e) {
			System.out.println("Error in getUserById() "+e.getMessage());
		}
		return user;
	}
	public static Boolean getCorrectAdmin(Short value){
		return value==0 ? true : false;
	}

	public synchronized int getNoOfRecords() {
		return noOfRecords;
	}
}

