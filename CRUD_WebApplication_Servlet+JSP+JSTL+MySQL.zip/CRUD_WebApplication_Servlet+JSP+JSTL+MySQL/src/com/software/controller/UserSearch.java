package com.software.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.software.db.UserUtil;

public class UserSearch extends HttpServlet{
	private static final long serialVersionUID = 1L;
	private String keyword = "";
	Connection conn;
	
	public UserSearch() {
		conn = UserUtil.getConnection();
	}
	public void headPage(HttpServletResponse resp)throws ServletException, IOException{
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		out.println("<html><head>");
		out.println("<title>Search Page</title>");
		out.println("</head><body>");
		out.println("<center><font size=\"5\"><b><br/><br/><br/>This is the search page in CRUD application."
				+ "<br/><br/></b></font><b>What to do want to search:</b>");
	}
	public void searchForm(HttpServletResponse resp)
			throws IOException,ServletException{
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		out.println("</br></br><form method=\"post\"><table><tr><th>Search</th>"
				+ "<td><input type=\"text\" name=\"keyword\" value=\""+keyword+"\" size=40>"
						+ "</td>");
		out.println("<td><input type=\"submit\"></td></tr></table>");
		out.println("</form>");	
	}
	public void searchResult(HttpServletResponse resp, HttpServletRequest req) 
			throws IOException,ServletException{
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		try {
			Statement st = conn.createStatement();
			out.println("<table><tr><th>ID</th>");
			out.println("<th>Name</th>");
			out.println("<th>Age</th>");
			out.println("<th>isAdmin</th>");
			out.println("<th>createdDate</th>");
			out.println("<th></th>");
			out.println("<th></th>");
			out.println("</tr>");
			String sql = "select id,name,age,isadmin,createdDate FROM users "
					+ "where id like '%"+keyword+"%' or name like "
							+ "'%"+keyword+"%' or age like '%"+keyword+
							"%'";
			ResultSet rs = st.executeQuery(sql);
			if(rs.next()){
				do{
					out.println("<tr>");
					out.println("<td align=\"center\">"+rs.getInt(1)+"</td>");
					out.println("<td align=\"center\">"+rs.getString(2)+"</td>");
					out.println("<td align=\"center\">"+rs.getString(3)+"</td>");
					out.println("<td align=\"center\">"+rs.getBoolean(4)+"</td>");
					out.println("<td align=\"center\">"+rs.getTimestamp(5)+"</td>");
					out.println("<td align=\"center\"><a href=UController?action=edit&id="+rs.getInt(1)+">Update</a></td>");
					out.println("<td align=\"center\"><a href=UController?action=delete&id="+rs.getInt(1)+">Delete</a></td>");
					out.println("</tr>");
				}
				while(rs.next());
			}
			else{
				out.println("<br/><br/><b>There are no elements. Please, write correct information!</b><br/><br/>");
			}
		} 
		catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		out.println("</table>");
		out.println("<a href=\""+req.getContextPath()+"/UController\"><br/>Back</a> to the User page!");
	}
	public void tailPage(HttpServletResponse resp) throws ServletException, IOException{
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		out.println("</center></body>");
		out.println("</html>");
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		headPage(resp);
		searchForm(resp);
		tailPage(resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		keyword = req.getParameter("keyword");
		headPage(resp);
		searchForm(resp);
		searchResult(resp,req);
		tailPage(resp);
	}
	
}
