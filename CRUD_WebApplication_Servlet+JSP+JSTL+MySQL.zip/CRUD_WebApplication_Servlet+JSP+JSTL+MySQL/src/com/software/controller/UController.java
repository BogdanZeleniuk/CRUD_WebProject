package com.software.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.software.dao.UserDao;
import com.software.model.User;

public class UController extends HttpServlet{
	private static final long serialVersionUID = 1L;
	private static final String ADD_AND_APPDATE = "/user.jsp";
	private static final String LIST_USER = "/listuserRR.jsp";
	UserDao dao;
	private volatile int page = 1;
	private volatile int recordsPerPage = 10;
	private volatile int noOfRecords;
	private volatile int noOfPages;
	private List<User> list;
	public UController() {
		super();
		dao = new UserDao();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String forward = "";
		String action = req.getParameter("action");
		
		if(req.getParameter("page") != null)
            page = Integer.parseInt(req.getParameter("page"));
		
		list = dao.getAllUser((page-1)*recordsPerPage, recordsPerPage);
		noOfRecords = dao.getNoOfRecords();
        noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
        
		if(action!=null && action.equalsIgnoreCase("delete")){
			String userid = req.getParameter("id");
			int userId = Integer.parseInt(userid);
			dao.deleteUser(userId);
			forward = LIST_USER;
			req.setAttribute("users", list);
			req.setAttribute("noOfPages", noOfPages);
	        req.setAttribute("currentPage", page);
		}
		else if(action!=null && action.equalsIgnoreCase("edit")){
			String userid = req.getParameter("id");
			int userId = Integer.parseInt(userid);
			User user = dao.getUserById(userId);
			forward = ADD_AND_APPDATE;
			req.setAttribute("user", user);
			req.setAttribute("noOfPages", noOfPages);
	        req.setAttribute("currentPage", page);
		}
		else if(action!=null && action.equalsIgnoreCase("listUser")){
			forward = LIST_USER;
			req.setAttribute("users", list);
	        req.setAttribute("noOfPages", noOfPages);
	        req.setAttribute("currentPage", page);
		}
		else if(action!=null && action.equalsIgnoreCase("search")){
			forward = LIST_USER;
			req.setAttribute("users", list);
	        req.setAttribute("noOfPages", noOfPages);
	        req.setAttribute("currentPage", page);
		}
		else{
			forward = ADD_AND_APPDATE;
		}
		RequestDispatcher rd = req.getRequestDispatcher(forward);
		rd.forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		User user = new User();
		user.setName(req.getParameter("name"));
		user.setAge(req.getParameter("age"));
		String isadmin = req.getParameter("isadmin");
		if("1".equals(isadmin)){
			user.setIsadmin(true);
		}
		else{
			user.setIsadmin(false);
		}
		
		try{
			Date reg = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH).parse(req.getParameter("createddate"));
			System.out.println("rrrrrrr"+reg);
			user.setCreateddate(reg);
		}
		catch(ParseException e){
			System.out.println("Error in doPost() "+e.getMessage());
		}
		String userId = req.getParameter("id");
		if(userId == null || userId.isEmpty())
        {
			dao.addUser(user);
        }
		else
        {
			user.setId(Integer.parseInt(userId));
            dao.updateUser(user);
        }
	
		RequestDispatcher rd = req.getRequestDispatcher(LIST_USER);
		req.setAttribute("users", list);
		req.setAttribute("noOfPages", noOfPages);
        req.setAttribute("currentPage", page);
		rd.forward(req, resp);
	}
	
}
